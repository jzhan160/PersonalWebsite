#devenv .\HelperComp\HelperComp.vcxproj /rebuild
#devenv .\UsingComp\HelperComp.vcxproj /rebuild
#devenv .\CppClient\CppClient.vcxproj /rebuild
devenv .\Project1Prototype.sln /rebuild