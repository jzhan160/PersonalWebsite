cd Debug
start CppClient.exe
cd ../