#!/bin/bash
rm *.o *.out