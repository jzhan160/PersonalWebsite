﻿///////////////////////////////////////////////////////////////////////////
// ChildProcss.cs - a child process for mother builder to run            //
//                                                                       //
// Biao A              ba1000@syr.edu                                    //    
// Application: CSE681 Project 4                                         //
// Environment: C# console                                               //
///////////////////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * This package includes the child process which is important part of process pool
 * The main duty of child process is to build a dll file.
 * 
 * public interface:
 * -------------------
 *  ChildProcess           - constructor: initialize some information
 *  initializeDispatcher   - add Actions to dictionary
 *  RcvThreadProc          - receive thread for child process
 *  PostReadyMsg           - send ready msg to mother builder
 *  
 *  other functions:
 *  BuildTest              - ask repo for files and build
 *  SendFiles              - send file to test harness
 *  RequestFile            - request repo to send files based on the xml file
 *  BuildTestHelper        - build a .dll file
 *  Logger                 - write log and send log to repo
 *  parseRequest           - parse the request
 *  SendTestRequest        - send test request to Test harness 
 *  cleaner                - clean all the temp files
 *  
 * Required Files:
 * ---------------
 *  FileMgr.cs               - need some funcitons to deal with files
 *  CommServer.cs            - need Comm project to send and receive messages and files
 *  Environment.cs           - get information like path, port...
 *  MyRequest.cs             - parse request to get information
 *  TestUtilities.cs            - need some functions in it
 * 
 * Maintenance History:
 *  --------------------
 *  ver 1.0 : 06 Dec 2017
 *  - first release
 */
using Microsoft.Build.Execution;
using Microsoft.Build.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;
using Microsoft.Build.Framework;

namespace Pro4
{
    public class ChildProcess
    {
        Comm comm { get; set; } = null;
        public string hostAddress { get; set; } = null;
        public int ID = 0;
        public string storagePath { get; set; }
        public Request request { get; set; } = new Request();
        Dictionary<string, Action<CommMessage>> messageDispatcher = new Dictionary<string, Action<CommMessage>>();

        //constructor: initialize some information
        public ChildProcess(string port, int id)
        {
            try
            {
                ID = id;
                hostAddress = port;
                comm = new Comm(hostAddress);
                string path = BuildServerEnvironment.childRoot + "/" + ID;
                FileMgr mgr = new FileMgr();
                mgr.CreateDirectory(path);
                storagePath = Path.GetFullPath(path);
                initializeDispatcher();
            }
            catch (Exception ex)
            {
                Console.Write("\n  {0}", ex.Message);
            }
        }

        //initialize messageDispatcher - add Actions to dictionary
        public void initializeDispatcher()
        {
            Action<CommMessage> buildTest = new Action<CommMessage>(BuildTest);
            messageDispatcher["BuildRequest"] = buildTest;

            Action<CommMessage> sendFiles = new Action<CommMessage>(SendFiles);
            messageDispatcher["FileRequest"] = sendFiles;
        }

        //ask repo for files and build
        private void BuildTest(CommMessage msg)
        {
            try
            {
                string notification = "Receive build request " + msg.Body + ". Saved in " + storagePath;
                TestUtilities.notification(notification);
                Thread.Sleep(1000);
                RequestFile(msg);
                BuildTestHelper(msg);
                string name = Path.GetFileNameWithoutExtension(request.testDriver);
                string dllPath = Path.Combine(storagePath, "dll", name + ".dll");
                bool flag = File.Exists(dllPath);
                Logger(msg, flag);
                if (flag)
                SendTestRequest(msg);
                PostReadyMsg();
                
            }
            catch (Exception ex)
            {
                Console.Write("\n  {0}", ex.Message);
            }
        }

        //send file to test harness
        private void SendFiles(CommMessage msg) {
            string dllName = msg.Body;
            string dllPath = Path.Combine(storagePath, "dll");
            comm.postFile(dllName, dllPath, TestHarnessEnvironment.root, TestHarnessEnvironment.address);
            string notification = "Sending " + dllName + " to TestHarness!";
            TestUtilities.notification(notification);
        }

        //receive thread for child process
        public void RcvThreadProc()
        {
            Console.Write("\n  starting child process's receive thread");
            while (true)
            {
                CommMessage msg = comm.getMessage();
                Console.Write("\n  Get message from {0}!", msg.Source);
                if (msg.Command == "Stop")
                    break;
                messageDispatcher[msg.Command](msg);
            }
        }

        //request repo to send files based on the xml file
        private void RequestFile(CommMessage msg)
        {
            List<string> filepath = new List<string>();
            string xmlName = msg.Body;
            TestUtilities.waitForCompletion(Path.Combine(storagePath, xmlName));
            parseRequest(xmlName);
            string notification = "Asking for test files...";
            TestUtilities.notification(notification);
            TestUtilities.requirment(3);
            CommMessage tdRequest = new CommMessage();
            tdRequest.Command = "FileRequest";
            tdRequest.Address = storagePath;
            tdRequest.Source = hostAddress;
            tdRequest.Body = request.testDriver;
            tdRequest.Destinaiton = "Repo";
            comm.postMessage(tdRequest, RepositoryEnvironment.address);
            string td = Path.Combine(storagePath, request.testDriver);
            filepath.Add(td);
            CommMessage tdpRequest = new CommMessage();
            tdpRequest.Command = "FileRequest";
            tdpRequest.Address = storagePath;
            tdpRequest.Source = hostAddress;
            tdpRequest.Destinaiton = "Repo";
            tdpRequest.Body = request.testDriverPro;
            comm.postMessage(tdpRequest, RepositoryEnvironment.address);
            string tdp = Path.Combine(storagePath, request.testDriverPro);
            filepath.Add(tdp);
            foreach (var file in request.testedFiles)
            {
                CommMessage tfRequest = new CommMessage();
                tfRequest.Command = "FileRequest";
                tfRequest.Body = file;
                tfRequest.Source = hostAddress;
                tfRequest.Destinaiton = "Repo";
                tfRequest.Address = storagePath;
                comm.postMessage(tfRequest, RepositoryEnvironment.address);
                string tf = Path.Combine(storagePath, file);
                filepath.Add(tf);
            }
            foreach (string file in filepath)
                TestUtilities.waitForCompletion(file);
        }

        //build a .dll file
        private bool BuildTestHelper(CommMessage msg)
        {
            Console.Write("\n  Building:");
            Thread.Sleep(500);
            try
            {
                string tdPath = Path.Combine(storagePath, request.testDriverPro);
                string projectFileName = @tdPath;
                ConsoleLogger logger = new ConsoleLogger();
                Dictionary<string, string> GlobalProperty = new Dictionary<string, string>();
                BuildRequestData BuildRequest = new BuildRequestData(projectFileName, GlobalProperty, null, new string[] { "Rebuild" }, null);
                BuildParameters bp = new BuildParameters();
                bp.Loggers = new List<ILogger> { logger };
                BuildResult buildResult = BuildManager.DefaultBuildManager.Build(bp, BuildRequest);
                Console.WriteLine();
                return true;
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.BackgroundColor = ConsoleColor.White;
                Console.Write("\n\n  An error occured while trying to build the csproj file.\n  Details: {0}\n\n", ex.Message);
                Console.ResetColor();
                return false;
            }
        }

        //write log and send log to repo
        private void Logger(CommMessage msg, bool flag)
        {
            string author = request.author;
            string name = Path.GetFileNameWithoutExtension(msg.Body);
            string time = DateTime.Now.ToString();
            string result = "succeed!";
            if (!flag) result = "failed";
            string log = "\n  Name : " + name + "\n  Author : " + author
                + "\n  Time : " + time + "\n  Build " + result;
            string logPath = Path.Combine(storagePath, "BuildLogFor" + name + ".txt");
            FileStream fs = new FileStream(logPath, FileMode.Create);
            StreamWriter sw = new StreamWriter(fs);
            sw.Write(log);
            sw.Flush();
            sw.Close();
            fs.Close();
            string notification = "Sending log:"+ "LogFor" + name + ".txt "+"to Repo!" ;
            TestUtilities.notification(notification);
            comm.postFile("BuildLogFor" + name + ".txt", storagePath,RepositoryEnvironment.root + "/log",RepositoryEnvironment.address);
        }

        //parse the request
        private void parseRequest(string xmlName)
        {
            try
            {
                string xmlFullName = Path.Combine(storagePath, xmlName);
                request.loadXml(xmlFullName);
                request.parse("author");
                request.parse("date");
                request.parse("testDriver");
                request.parse("testDriverPro");
                request.parseList("tested");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

        }

        //send ready msg to mother builder
        public void PostReadyMsg()
        {
            try
            {
                CommMessage readyMsg = new CommMessage();
                readyMsg.Source = hostAddress;
                readyMsg.Body = ID.ToString();
                readyMsg.Command = "Ready";
                readyMsg.Destinaiton = "Mother Builder";
                comm.postMessage(readyMsg, BuildServerEnvironment.address);
            }
            catch (Exception ex)
            {
                Console.Write("\n  {0}", ex.Message);
            }
        }

        //send test request to Test harness  
        private void SendTestRequest(CommMessage msg)
        {
            Thread t = new Thread(()=> {
                string notification = "Sending test request to test harness";
                TestUtilities.notification(notification);
                TestUtilities.requirment(8);
                comm.postFile(msg.Body, storagePath, TestHarnessEnvironment.root, TestHarnessEnvironment.address);
                CommMessage testRequest = new CommMessage();
                testRequest.Body = msg.Body;
                testRequest.Source = "child builder:" + ID;
                testRequest.Destinaiton = "Test Harness";
                testRequest.Command = "TestRequest";
                testRequest.Address = hostAddress;
                comm.postMessage(testRequest, TestHarnessEnvironment.address);
            });
            t.Start();
        }

        //clean all the temp files
        private void cleaner() {
            FileMgr mgr = new FileMgr();
            mgr.Cleaner(storagePath);
        }
    }
    class test
    {

        static void Main(string[] args)
        {
            string port = args[0];
            int id = Process.GetCurrentProcess().Id;
            TestUtilities.title("I am #" + id + " child process");
            ChildProcess child = new ChildProcess(port, id);
            string msg = "Open host at " + child.hostAddress;
            TestUtilities.title(msg);
            TestUtilities.requirment(6);
            string root = "My root is " + child.storagePath;
            TestUtilities.title(root);
            TestUtilities.requirment(7);
            child.PostReadyMsg();
            Thread t = new Thread(() => child.RcvThreadProc());
            t.Start();
            t.Join();
            //Console.ReadKey();

        }
    }
}
