﻿/////////////////////////////////////////////////////////////////////////////
// CommService.cs - provide all operations about information passing       //
//                                                                         //
// Biao A              ba1000@syr.edu                                      //    
// Application: CSE681 Project 4                                           //
// Environment: C# console                                                 //
/////////////////////////////////////////////////////////////////////////////
/* Ps: some codes come from 681 website
 * Package Operations:
 * -------------------
 * This package includes three class which are all dedicated to information transmission
 * --------------------------------------------------------------------------
 * Receiver class - receives CommMessages and Files from Senders
 * Receiver               - create an empty blocking queue
 * CreateHost             - create a host for receiving msg
 * PostMessage            - enqueue a message
 * GetMessage             - dequeue a message (when type == 0 deQ mQueue else deQ readyQueue)
 * openFileForWrite       - called by Sender's channel to open file on Receiver
 * writeFileBlock         - write file block
 * closeFile              - close file
 * cleanReadyQ            - clean the readyQ for Build Server to restart child process
 * ---------------------------------------------------------------------------
 * Sender class - sends messages and files to Receiver
 * Sender                 - constructor
 * PostMessage            - using channel to send a message
 * CreateChannel          - using url to create a channel
 * postFile               - post files to receiver
 * getClientFileList      - get all client file in directory
 * ---------------------------------------------------------------------------
 * Comm class - combines Receiver and Sender
 * Comm                   - initialize host
 * postMessage            - post message to remote Comm
 * getMessage             - retrieve message from remote Comm
 * postFile               - called by remote Comm to upload file
 * cleanReadyQ            - clean the ready Q to restart the child process
 * 
 * Required Files:
 * ---------------
 * BlockingQueue.cs       - using the thread-safe queue to store and get message
 * IComm.cs               - service contract
 * 
 *  Maintenance History:
 *  --------------------
 *  ver 1.0 : 06 Dec 2017
 *  - first release
 */
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace Pro4
{
    // Receiver class - receives CommMessages and Files from Senders
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
    public class Receiver : IComm
    {
        static BlockingQueue<CommMessage> mQueue { get; set; }
        static BlockingQueue<CommMessage> readyQueue { get; set; }
        public static string WDeirectory { get; set; } = "../../../Comm/HostStorage";
        static FileStream fs { get; set; }
        ServiceHost Host = null;
        string lastError { get; set; } = null;
        public string Address { get; private set; }

        //constructor: create an empty blocking queue
        public Receiver()
        {
            if (mQueue == null)
                mQueue = new BlockingQueue<CommMessage>();
            if (readyQueue == null)
                readyQueue = new BlockingQueue<CommMessage>();

            Host = null;

        }

        //create a host for receiving msg
        public void CreateHost(string baseAddress)
        {
            Uri uri = new Uri(baseAddress);
            Address = uri.AbsoluteUri;
            BasicHttpBinding binding = new BasicHttpBinding();

            Host = new ServiceHost(typeof(Receiver), uri);
            Host.AddServiceEndpoint(typeof(IComm), binding, uri);
            Host.Open();
        }

        //enqueue a message
        [OperationBehavior(TransactionAutoComplete = true)]
        public void PostMessage(CommMessage msg)
        {
            if (msg.Command == "Ready")
            {
                readyQueue.enQ(msg);
            }
            else
                mQueue.enQ(msg);
        }

        //dequeue a message (when type == 0 deQ mQueue else deQ readyQueue)
        [OperationBehavior]
        public CommMessage GetMessage(int type)
        {
            if (type == 0)
                return mQueue.deQ();
            else
                return readyQueue.deQ();
        }

        //called by Sender's channel to open file on Receiver
        [OperationBehavior]
        public bool openFileForWrite(string path, string name)
        {
            try
            {
                string writePath = Path.Combine(path, name);
                fs = File.OpenWrite(writePath);
                return true;
            }
            catch (Exception ex)
            {
                lastError = ex.Message;
                Console.WriteLine(lastError);
                return false;
            }
        }

        // write file block
        [OperationBehavior]
        public bool writeFileBlock(byte[] block)
        {
            try
            {
                fs.Write(block, 0, block.Length);
                return true;
            }
            catch (Exception ex)
            {
                lastError = ex.Message;
                Console.WriteLine("Error in writing!!!");
                Console.WriteLine(lastError);
                return false;
            }
        }

        //clean the readyQ for Build Server to restart child process
        public void cleanReadyQ() {
            readyQueue.clear();
        }

        //close file
        [OperationBehavior]
        public void closeFile()
        {
            try
            {
                fs.Close();
            }
            catch (Exception ex)
            {
                lastError = ex.Message;
                Console.WriteLine(lastError);
            }

        }
    }

    // Sender class - sends messages and files to Receiver
    public class Sender
    {
        IComm channel;
        public static string StoragePath { get; set; } = "../../../Comm/SenderStorage";
        string lastError { get; set; } = null;
        int blockSize = 1024;

        //constructor
        public Sender()
        {
        }

        //using channel to send a message
        public void PostMessage(CommMessage msg)
        {
            if (channel == null)
            {
                Console.Write("\n  Cannot send message. The channel is not initial.");
                return;
            }
            channel.PostMessage(msg);
        }

        //using url to create a channel
        public void CreateChannel(string url)
        {
            BasicHttpBinding binding = new BasicHttpBinding();

            binding.TransferMode = TransferMode.Streamed;
            binding.MaxReceivedMessageSize = 5368709120;
            EndpointAddress address = new EndpointAddress(url);

            channel = ChannelFactory<IComm>.CreateChannel(binding, address);
        }

        //post files to receiver
        public bool postFile(string fileName, string filepath, string destination)
        {
            FileStream fs = null;
            long bytesRemaining;
            try
            {
                string path = Path.Combine(filepath, fileName);
                fs = File.OpenRead(path);
                bytesRemaining = fs.Length;
                channel.openFileForWrite(destination, fileName);
                while (true)
                {
                    long bytesToRead = Math.Min(blockSize, bytesRemaining);
                    byte[] blk = new byte[bytesToRead];
                    long numBytesRead = fs.Read(blk, 0, (int)bytesToRead);
                    bytesRemaining -= numBytesRead;

                    channel.writeFileBlock(blk);
                    if (bytesRemaining <= 0)
                        break;
                }
                channel.closeFile();
                fs.Close();
            }
            catch (Exception ex)
            {
                lastError = ex.Message;
                Console.WriteLine(lastError);
                return false;
            }
            return true;
        }

        //get all client file in directory
        public static List<string> getClientFileList()
        {
            List<string> names = new List<string>();
            string[] files = Directory.GetFiles(StoragePath);
            foreach (string file in files)
            {
                names.Add(Path.GetFileName(file));
            }
            return names;
        }
    }

    //Comm class - combines Receiver and Sender
    public class Comm
    {
        private Receiver rcvr = null;
        private Sender sndr = null;
        private string address = null;

        //constructor - initialize host
        public Comm(string baseAddress)
        {
            address = baseAddress;
            rcvr = new Receiver();
            rcvr.CreateHost(baseAddress);
            sndr = new Sender();
        }
        
        //post message to remote Comm
        public void postMessage(CommMessage msg, string port)
        {
            sndr.CreateChannel(port);
            sndr.PostMessage(msg);
        }

        //retrieve message from remote Comm
        public CommMessage getMessage(int type = 0)
        {
            if (type == 1)
                return rcvr.GetMessage(1);
            return rcvr.GetMessage(0);
        }

        //called by remote Comm to upload file
        public bool postFile(string fileName, string filepath, string destination,string port)
        {
            sndr.CreateChannel(port);
            return sndr.postFile(fileName, filepath, destination);
        }

        //clean the ready Q to restart the child process
        public void cleanReadyQ() {
            try
            {
                rcvr.cleanReadyQ();
            }
            catch (Exception ex)
            {
                Console.Write("\n  {0}", ex.Message);
            }
        }
    }

#if (TEST_COMMSERVICE)
    class Program
    {
       
        static void Main(string[] args)
        {
            string host = "http://localhost:9888/CommTest";
            Comm comm = new Comm(host);
            CommMessage testMsg = new CommMessage();
            testMsg.Body = "test";
            comm.postMessage(testMsg, host);
            CommMessage msg = comm.getMessage();
            Console.Write("\n  {0}", msg.Body);
            string fileName = "";//enter file Name
            string filepath = "";//enter file path
            string destination = "";//enter destination
            comm.postFile(fileName, filepath, destination, host);
        }

}
#endif
}
