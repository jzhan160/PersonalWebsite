﻿/////////////////////////////////////////////////////////////////////
// Loader.cs - Loads test libraries into Test Application Domain   //
// ver 1.1                                                         //
//                                                                 //
// Platform:    Dell Dimension 8300, Windows XP Pro, SP 2.0        //
// Application: CSE784 - Software Studio, Final Project Prototype  //
// Author:      Jim Fawcett, Syracuse University, CST 2-187        //
//              jfawcett@twcny.rr.com, (315) 443-3948              //
/////////////////////////////////////////////////////////////////////
/*
 * Module Operations:
 * ==================
 * This module provides operations to load test assemblies into a
 * child application domain, called TestDomain.  Interestingly, this
 * code runs in TestDomain.  This is necessary so that the primary
 * application domain of the test harness does not need to have any
 * information about the test types it will invoke, remotely, in
 * TestDomain.
 * 
 * Note: code shows options for loading from AppDomain.Load(...).
 * That is not used here, since we want to load from a specified
 * Directory.
 * 
 * Public Interface:
 * =================
 * AppDomain ad = AppDomain.CreateDomain("TestDomain",evidence,domainInfo);
 * ad.Load("Loader");
 * ObjectHandle oh = ad.CreateInstance("loader","TestHarness.Loader");
 * Loader ldr = oh.Unwrap() as Loader;
 * ldr.SetPath(pathToLibs_);
 * ldr.RunTests();
 * 
 * Maintenance History:
 * --------------------
 * ver 1.0 : 06 Dec 2017
 * - Delete some functions by Biao A
 */

using System;
using System.IO;
using System.Text;
using System.Xml;
using System.Reflection;
using System.Threading;

namespace Pro4
{
    public class Loader : MarshalByRefObject
    {
        string pathToTestLibs_;

        //----< Constructor placeholder >--------------------------------

        public Loader()
        {
        }
        public void SetPath(string path)
        {
            pathToTestLibs_ = path;
        }

        //run test and return result
        public string RunTests()
        {
            Console.Write("\n\n  Running Tests in TestDomain");
            Console.Write("\n -----------------------------");
            string logtxt = "";
            try
            {
                Thread.Sleep(1000);
                Assembly asm = Assembly.LoadFile(pathToTestLibs_);
                Type[] types = asm.GetTypes();
                foreach (var t in types)
                {
                    if (!t.IsInterface)
                    {
                        MethodInfo method = t.GetMethod("TEST");
                        object obj = asm.CreateInstance(t.ToString());
                        bool result = Convert.ToBoolean(method.Invoke(obj, null));

                        Func<bool, string> act = (bool pass) =>
                        {
                            if (pass)
                                return "passed!";
                            return "failed!";
                        };

                        string testResult = "\n " + t.ToString() + " " + act(result);
                        logtxt += testResult;
                    }
                }
                return logtxt;
            }
            catch (Exception ex)
            {
                logtxt = "\n " + ex.Message;
                Console.Write(logtxt);
                return logtxt;
            }
        }
    }

#if (TEST_LOADER)
    class Program
    {
       
        static void Main(string[] args)
        {
            Loader ldr = new Loader();
            string dllpath = "testloader.dll";
            ldr.SetPath(Path.GetFullPath(dllpath));
            string result = ldr.RunTests();
            Console.WriteLine(result);
        }

}
#endif
}
