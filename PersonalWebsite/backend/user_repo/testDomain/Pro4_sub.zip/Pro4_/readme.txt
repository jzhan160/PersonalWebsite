1. All the files are listed in "Federation" dir.
2. I prepare two test cases each with two tests in it. TestB cannot build sucessfully.
3. This GUI will first automatically show the build and test process. When the demonstration is end, please press the "STOP" button to stop child process. Then please follow the instrution in GUI.