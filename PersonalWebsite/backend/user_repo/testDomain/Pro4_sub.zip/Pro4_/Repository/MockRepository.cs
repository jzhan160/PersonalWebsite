﻿/////////////////////////////////////////////////////////////////////////////////
// MockRepository.cs - a mock repo for demonstrating functions of other parts  //
//                                                                             //
// Biao A              ba1000@syr.edu                                          //    
// Application: CSE681 Project 4                                               //
// Environment: C# console                                                     //
/////////////////////////////////////////////////////////////////////////////////
/* Ps: some codes come from 681 website
 * 
 * Package Operations:
 * -------------------
 *  Repository mainly provides function to store files. Client can browse its files through GUI.
 *  
 *  public interfaces:
 *  Repository               - constructor:clean files and set path
 *  initializeDispatcher     - add Actions to dictionary(message dispatcher)
 *  RcvThreadProc            - receive thread for repository
 *
 *  other funcitons:
 *  SendFileList             - send local file list to Client
 *  GotRequest               - print out a message when have got a request
 *  SendRequestList          - send request list in repo to client
 *  SendRequest              - send request file(.xml) to build server
 *  sendDir                  - send local dir to client
 * 
 *  Required Files:
 * ---------------
 *  FileMgr.cs               - need some funcitons to deal with files
 *  CommServer.cs            - need Comm project to send and receive messages and files
 *  Environment.cs           - get information like path, port...
 *  MyRequest.cs             - parse request to get information
 *  TestUtilities.cs         - need some functions in it
 *  
 *  Maintenance History:
 * --------------------
 * ver 1.0 : 06 Dec 2017
 * - first release
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;

namespace Pro4
{
    class Repository
    {
        Dictionary<string, Action<CommMessage>> messageDispatcher = new Dictionary<string, Action<CommMessage>>();
        Comm comm { get; set; } = null;
        string path { get; set; } = "";

        //constructor:clean files and set path
        public Repository()
        {
            try
            {
                FileMgr mgr = new FileMgr();
                mgr.Cleaner(RepositoryEnvironment.root + "/log");
                //mgr.Cleaner(RepositoryEnvironment.root + "/request");
                path = Path.GetFullPath(RepositoryEnvironment.root);
                comm = new Comm(RepositoryEnvironment.address);
            }
            catch(Exception ex)
            {
                Console.WriteLine("\n  {0}", ex.Message);
            }
        }

        //initialize messageDispatcher - add Actions to dictionary(message dispatcher)
        public void initializeDispatcher()
        {
            Action<CommMessage> sendFileList = new Action<CommMessage>(SendFileList);
            messageDispatcher["FileListRequest"] = sendFileList;

            Action<CommMessage> sendFiles = new Action<CommMessage>(SendFiles);
            messageDispatcher["FileRequest"] = sendFiles;
            
            Action<CommMessage> gotRequest = new Action<CommMessage>(GotRequest);
            messageDispatcher["Request"] = gotRequest;

            Action<CommMessage> sendDir = new Action<CommMessage>(SendDir);
            messageDispatcher["DirRequest"] = sendDir;

            Action<CommMessage> sendRequestList = new Action<CommMessage>(SendRequestList);
            messageDispatcher["RequestList"] = sendRequestList;

            Action<CommMessage> sendRequest = new Action<CommMessage>(SendRequest);
            messageDispatcher["SendRequest"] = sendRequest;
        }

        //send local file list to Client
        private void SendFileList(CommMessage msg)
        {
            try
            {
                FileMgr mgr = new FileMgr();
                CommMessage reply = new CommMessage();
                mgr.GetFile(path + "/testfiles" + "/"+msg.Body);
                List<string> fileNames = mgr.GetFileName();
                CommMessage fileMsg = new CommMessage();
                fileMsg.Source = "repo";
                fileMsg.Destinaiton = "Client";
                fileMsg.Body = "files list in MsgList";
                fileMsg.MsgList = fileNames;
                fileMsg.Command = "repoFiles";
                comm.postMessage(fileMsg, ClientEnvironment.address);
            }
            catch (Exception ex)
            {
                Console.Write("\n  {0}", ex.Message);
            }
        }

        //send local dir to client
        private void SendDir(CommMessage msg)
        {
            try
            {
                CommMessage dirMsg = new CommMessage();
                dirMsg.Body = "dir list";
                dirMsg.Destinaiton = "Client";
                dirMsg.Source = "Repo";
                List<string> dirList = new List<string>();
                dirList = Directory.GetDirectories(path + "/testfiles").ToList<string>();
                List<string> msgList = new List<string>();
                foreach (var dir in dirList)
                {
                    string dirName = new DirectoryInfo(dir).Name;
                    msgList.Add(dirName);
                }
                dirMsg.MsgList = msgList;
                dirMsg.Command = "DirList";
                comm.postMessage(dirMsg, ClientEnvironment.address);
            }
            catch (Exception ex)
            {
                Console.Write("\n  {0}",ex.Message);
            }
        }

        //send files to child builder based on msg
        private void SendFiles(CommMessage msg)
        {
            try
            {
                string storagePath;
                if (msg.Body.Contains("A"))
                {
                    storagePath = path + "/testfiles"+"/TestA";
                }
                else
                {
                    storagePath = path + "/testfiles"+ "/TestB";
                }   
                string notification = "Got file request from child process!";
                TestUtilities.notification(notification);
                comm.postFile(msg.Body, storagePath, msg.Address, msg.Source);
            }
            catch (Exception ex)
            {
                Console.Write("\n  {0}", ex.Message);
            }
        }

        //print out a message when have got a request
        private void GotRequest(CommMessage msg)
        {
            string xmlName = msg.Body;
            string xmlPath = path + "/request";
            try
            {
                Console.Write("\n  Received {0} from Client!", xmlName);
                string notification = "Saved in " + Path.GetFullPath(xmlPath);
                TestUtilities.notification(notification);
            }
            catch (Exception ex)
            {
                Console.Write("\n  {0}", ex.Message);
            }
        }

        //send request list in repo to client
        private void SendRequestList(CommMessage msg)
        {
            try
            {
                FileMgr mgr = new FileMgr();
                CommMessage reply = new CommMessage();
                mgr.GetFile(path + "/request");
                List<string> requestNames = mgr.GetFileName();

                CommMessage requestMsg = new CommMessage();
                requestMsg.Source = "repo";
                requestMsg.Destinaiton = "Client";
                requestMsg.Body = "request list in MsgList";
                requestMsg.MsgList = requestNames;
                requestMsg.Command = "repoRequest";
                comm.postMessage(requestMsg, ClientEnvironment.address);
            }
            catch (Exception ex)
            {
                Console.Write("\n  {0}", ex.Message);
            }
        }

        //send request file(.xml) to build server
        private void SendRequest(CommMessage msg)
        {
            comm.postFile(msg.Body, path + "/request", BuildServerEnvironment.root, BuildServerEnvironment.address);
            Thread.Sleep(1000);//wait for the completion of file transfer
            CommMessage buildRequest = new CommMessage();
            buildRequest.Command = "BuildRequest";
            buildRequest.Source = "Repo";
            buildRequest.Body = msg.Body;
            buildRequest.Destinaiton = "BuildServer";
            comm.postMessage(buildRequest, BuildServerEnvironment.address);

        }

        //receive thread for repository
        public void RcvThreadProc()
        {
            Console.Write("\n  starting repository's receive thread");
            while (true)
            {
                CommMessage msg = comm.getMessage();
                Console.Write("\n  Get message from {0}!", msg.Source);
                messageDispatcher[msg.Command](msg);
            }
        }
    }
    class test
    {
        static void Main()
        {
            TestUtilities.title("This is Repository");
            Repository repo = new Repository();
            repo.initializeDispatcher();
            Thread t = new Thread(()=>repo.RcvThreadProc());
            t.Start();
            t.Join();
            Console.ReadKey();
        }
    }
}
