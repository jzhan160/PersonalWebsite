﻿///////////////////////////////////////////////////////////////////////////
// Executive.cs - demonstrate pro 4                                      //
//                                                                       //
// Biao A              ba1000@syr.edu                                    //    
// Application: CSE681 Project 4                                         //
// Environment: C# console                                               //
///////////////////////////////////////////////////////////////////////////
/* 
 * Package Operations:
 * -------------------
 * This package only includes one 
 * 
 * Maintenance History:
 *  --------------------
 * ver 1.0 : 06 Dec 2017
 *  - first release
*/
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Executive
{
    class test
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("\n  Demonstrating... ");
                Process.Start(Path.GetFullPath("../../../Repository/bin/Debug/Repository.exe"));
                Process.Start(Path.GetFullPath("../../../TestHarness/bin/Debug/TestHarness.exe"));
                Process.Start(Path.GetFullPath("../../../BuildServer/bin/Debug/BuildServer.exe"));
                Process.Start(Path.GetFullPath("../../../GUI/bin/Debug/GUI.exe"));
                Console.ReadKey();

            }
            catch (Exception ex)
            {
                Console.Write("\n  {0}", ex.Message);
            }
        }
    }
}
