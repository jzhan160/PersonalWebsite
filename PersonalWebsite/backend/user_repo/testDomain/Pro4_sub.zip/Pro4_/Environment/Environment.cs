﻿/////////////////////////////////////////////////////////////////////////////
// Environment.cs - store all the information(path,port...)                //
//                                                                         //
// Biao A              ba1000@syr.edu                                      //    
// Application: CSE681 Project 4                                           //
// Environment: C# console                                                 //
/////////////////////////////////////////////////////////////////////////////
/* 
 * Package Operations:
 * -------------------
 * This package store  all the information(path,port...) togather for the ease to manage.
 * 
 * including:
 * RepositoryEnvironment
 * BuildServerEnvironment
 * TestHarnessEnvironment
 * ClientEnvironment
 *  
 *  Maintenance History:
 *  --------------------
 *  ver 1.0 : 06 Dec 2017
 *  - first release
 * 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pro4
{

    public struct RepositoryEnvironment
    {
        //root path for Repo
        public static string root { get; set; } = "../../../Federation/RepoStorage";
        //port for repo
        public static string address { get; set; } = "http://localhost:9888/Repo";
    }

    public struct BuildServerEnvironment
    {
        //root path for Build Server
        public static string root { get; set; } = "../../../Federation/BuildServer";
        //port for BS
        public static string address { get; set; } = "http://localhost:9888/Builder";
        //port for child processes
        public static string childport { get; set; } = "http://localhost:933";
        //root path for child processes
        public static string childRoot { get; set; } = "../../../Federation/ProcessPool";
        //the exe file of child processes
        public static string childExePath { get; set; } = "../../../ChildBuilder/bin/Debug/ChildBuilder.exe";

    }

    public struct TestHarnessEnvironment
    {
        //root path for Test Harness
        public static string root { get; set; } = "../../../Federation/TestHarness";
        //port for Test Harness
        public static string address { get; set; } = "http://localhost:9888/TestH";
    }

    public struct ClientEnvironment
    {
        //root path for Client
        public static string root { get; set; } = "../../../Federation/Client";
        //port for client
        public static string address { get; set; } = "http://localhost:9888/Client";
    }


}
