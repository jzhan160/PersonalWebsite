using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testdriver1
{
    class test2 : Test
    {
        public bool TEST()
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.BackgroundColor = ConsoleColor.White;
            Console.Write("\n  Testing test2...");
            Console.ResetColor();
            return false;
        }
    }
}