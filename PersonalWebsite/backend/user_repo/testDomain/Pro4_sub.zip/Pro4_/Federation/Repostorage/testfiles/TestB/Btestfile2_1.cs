﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testdriver1
{
    class test1 : Test
    {
        public bool TEST()
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.BackgroundColor = ConsoleColor.White;
            Console.Write("\n  Testing test1...");
            Console.ResetColor();
            return true;
        }
    }
}
