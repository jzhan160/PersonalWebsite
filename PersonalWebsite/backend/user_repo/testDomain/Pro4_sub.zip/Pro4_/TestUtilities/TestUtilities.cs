﻿///////////////////////////////////////////////////////////////////////////
// TestUtilities.cs - Receive request and test files                     //
//                                                                       //
// Biao A              ba1000@syr.edu                                    //    
// Application: CSE681 Project 4                                         //
// Environment: C# console                                               //
///////////////////////////////////////////////////////////////////////////
/*
* Package Operations:
* ===================
* This package includes some functions which will be used many time in this solution such
* as printing a title. So I package them all for the ease to use and manage.
*
* Public Interface:
* title                    - print titles
* requirment               - demonstrate which requirment I have achieved
* notification             - show some important messages
* waitForCompletion        - wait for the completion of tranmission of file
* 
* Maintenance History:
* --------------------
* ver 1.0 : 06 Dec 2017
* - first release
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;

namespace Pro4
{
    public class TestUtilities
    {
        // print titles
        public static void title(string msg, char ch = '-')
        {
            Console.Write("\n  {0}", msg);
            Console.Write("\n {0}", new string(ch, msg.Length + 2));
        }

        //demonstrate which requirment I have achieved
        public static void requirment(int i)
        {
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("\n  Requirment {0}",i);
            Console.ResetColor();
        }

        //show some important message
        public static void notification(string msg)
        {
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("\n  {0}", msg);
            Console.ResetColor();
        }

        //wait for the completion of tranmission of file
        public static void waitForCompletion(string filepath)
        {
            while (true) {
                if (!File.Exists(filepath))
                {
                    Thread.Sleep(100);
                    continue;
                }
                break;
            }
        }
    }
#if (TEST_TESTUTILITIES)
    class Program
    {
       
        static void Main(string[] args)
        {
            string notification = "alalalalla";
            TestUtilities.notification(notification);

            TestUtilities.requirment(2);
            TestUtilities.requirment(3);

            string filepath = "TestHarness.exe";
            TestUtilities.waitForCompletion(filepath);

        }

}
#endif
}
