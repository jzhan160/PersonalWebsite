﻿/////////////////////////////////////////////////////////////////////////////
// FileMgr.cs - operation about files                                      //
//                                                                         //
// Biao A              ba1000@syr.edu                                      //    
// Application: CSE681 Project 4                                           //
// Environment: C# console                                                 //
/////////////////////////////////////////////////////////////////////////////
/* Ps: some codes come from 681 website
 * 
 * Package Operations:
 * -------------------
 * This package including some functions about operation related to files and dirs.
 * 
 *  public interfaces
 *  FileMgr               - constructor
 *  GetFileHelper         - helper to get all files in Storage
 *  GetFile               - get all files in StoragePath(including path)
 *  GetFileName           - get all files' name(without path and it is for GUI)
 *  CreateDirectory       - create dir
 *  Cleaner               - cleaner: delete all files under a specific directory
 *  DeleteFileList        - delete files in this list
 *  
 *  Maintenance History:
 *  --------------------
 *  ver 1.0 : 06 Dec 2017
 *  - first release
 */
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pro4
{
    public class FileMgr
    {
        public List<string> Files { get; set; } = null;

        //constructor
        public FileMgr()
        {
            Files = new List<string>();
        }

        //helper to get all files in Storage
        private void GetFileHelper(string path)
        {
            String[] GetFiles = Directory.GetFiles(path);
            Files.AddRange(GetFiles);
            String[] Dirs = Directory.GetDirectories(path);
            foreach (String dir in Dirs)
            {
                GetFileHelper(dir);
            }
        }

        //get all files in StoragePath(including path)
        public void GetFile(string path)
        {
            Files.Clear();
            GetFileHelper(path);
        }

        //get all files' name(without path and it is for GUI)
        public List<string> GetFileName()
        {
            List<string> fileNames = new List<string>();
            
            foreach (var file in Files)
            {
                fileNames.Add( Path.GetFileName(file));
            }
            return fileNames;
        }

        //create dir
        public void CreateDirectory(string path)
        {
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
        }

        //cleaner: delete all files under a specific directory
        public void Cleaner(string storagePath)
        {
            Console.Write("");
            try
            {
                DirectoryInfo dir = new DirectoryInfo(storagePath);
                FileSystemInfo[] fileinfo = dir.GetFileSystemInfos();
                foreach (FileSystemInfo i in fileinfo)
                {
                    if (i is DirectoryInfo)
                    {
                        DirectoryInfo subdir = new DirectoryInfo(i.FullName);
                        subdir.Delete(true);
                    }
                    else
                    {
                        File.Delete(i.FullName);
                    }

                }
                Console.Write("\n  Cleaned all temporary Succeed!");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //delete files in this list
        public void DeleteFileList(List<string> fileList)
        {
            try
            {
                foreach (string file in fileList)
                {
                    File.Delete(file);
                }
                Console.Write("\n  Cleaned all files!");
            }
            catch (Exception ex) {
                Console.Write("\n  {0}",ex.Message);
            }

        }
    }

#if (TEST_FileMgr)
    class test
    {
        static void Main(string[] args)
        {
            string filepath = "";//enter a path of a test dir
            FileMgr s = new FileMgr();
            s.GetFile(filepath);
            s.GetFileName();
            s.CreateDirectory(filepath);
            s.Cleaner(filepath);
            List<string> filelist = new List<string>();
            //enter filelist...
            s.DeleteFileList(filelist);

        }
    }
#endif
}
