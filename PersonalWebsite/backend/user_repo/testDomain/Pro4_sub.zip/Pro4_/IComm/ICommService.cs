﻿///////////////////////////////////////////////////////////////////////////
// IComm.cs - interface for communication                                //
//                                                                       //
// Biao A              ba1000@syr.edu                                    //    
// Application: CSE681 Project 4                                         //
// Environment: C# console                                               //
///////////////////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * -------------------
 * This package includes one interface and one data class which are used in WCF
 * communication.
 * 
 * Comm interface:
 * PostMessage             - post a message to host's queue
 * openFileForWrite        - open a file to write 
 * writeFileBlock          - write file block
 * closeFile               - close file
 * 
 * Comm data : CommMessage
 * source         - message sender
 * Destinaiton    - message receiver
 * Address        - host address of message sender
 * MsgList        - send messages in a list like file list
 * Body           - main information of a message
 * Command        - message type for message dispatcher
 * 
 * Maintenance History:
 * --------------------
 * ver 1.0 : 06 Dec 2017
 * - first release
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.Runtime.Serialization;

namespace Pro4
{
    using Command = String;
    [ServiceContract]
    public interface IComm
    {
        //post a message to host's queue
        [OperationContract(IsOneWay = true)]
        void PostMessage(CommMessage msg);

        //open a file to write
        [OperationContract]
        bool openFileForWrite(string path, string name);

        //write file block
        [OperationContract]
        bool writeFileBlock(byte[] block);

        //close file
        [OperationContract(IsOneWay = true)]
        void closeFile();
    }

    [DataContract]
    public class CommMessage
    {
        [DataMember]
        public string Source { get; set; }

        [DataMember]
        public string Destinaiton { get; set; }

        [DataMember]
        public string Address { get; set; }

        [DataMember]
        public List<string> MsgList { get; set; }

        [DataMember]
        public string Body { get; set; }

        [DataMember]
        public Command Command { get; set; }
    }
}
