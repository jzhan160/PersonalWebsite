﻿///////////////////////////////////////////////////////////////////////////
// MyRequest.cs - for creating, loading, saving...XML files              //
//                                                                       //
// Biao A              ba1000@syr.edu                                    //    
// Application: CSE681 Project 4                                         //
// Environment: C# console                                               //
///////////////////////////////////////////////////////////////////////////
/* Ps: some codes come from 681 website
 * 
 * Package Operations:
 * -------------------
 * This package includes some functions about handle xml. file which will help
 * other project deal with xml request.
 * 
 *  public interfaces:
 *  makeRequestXml     - make a request
 *  loadXml            - load a Xml file
 *  saveXml            - save doc to a Xml fileg
 *  parse              - parse author, date, testDriver
 *  parseList          - parse tested file
 *  
 *  Maintenance History:
 * --------------------
 * ver 1.0 : 06 Dec 2017
 * - first release
 * 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Pro4
{
    public class Request
    {
        public string author { get; set; } = "";
        public string date { get; set; } = "";
        public string testDriver { get; set; } = "";
        public string testDriverPro { get; set; } = "";
        public List<string> testedFiles { get; set; } = new List<string>();
        public XDocument doc { get; set; } = new XDocument();
        public string xmlName { get; set; } = "Request.xml";

        //make a request
        public void makeRequestXml()
        {

            //testRequest
            XElement testRequestE = new XElement("testRequest");
            doc.Add(testRequestE);

            //author
            XElement authorE = new XElement("author");
            authorE.Add(author);
            testRequestE.Add(authorE);

            //date
            XElement date = new XElement("date");
            date.Add(DateTime.Now.ToString());
            testRequestE.Add(date);

            //test
            XElement test = new XElement("test");
            testRequestE.Add(test);

            //testDriver.cs
            XElement testDriverE = new XElement("testDriver");
            test.Add(testDriverE);
            testDriverE.Add(testDriver);

            //testDriver.pro
            XElement testDriverProE = new XElement("testDriverPro");
            test.Add(testDriverProE);
            testDriverProE.Add(testDriverPro);

            //tested files
            foreach (string file in testedFiles)
            {
                XElement testedFileElem = new XElement("tested");
                testedFileElem.Add(file);
                test.Add(testedFileElem);
            }
        }

        //load a Xml file
        public bool loadXml(string path)
        {
            try
            {
                doc = XDocument.Load(path);
                return true;
            }
            catch (Exception ma)
            {
                Console.WriteLine(ma);
                return false;
            }
        }

        //save doc to a Xml file
        public bool saveXml(string path)
        {
            try
            {
                doc.Save(path);
                return true;
            }
            catch (Exception ex)
            {
                Console.Write("\n--{0}--\n", ex.Message);
                return false;
            }
        }

        //parse author, date, testDriver
        public string parse(string propertyName)
        {
            string parseStr = doc.Descendants(propertyName).First().Value;
            if (parseStr.Length > 0)
            {
                switch (propertyName)
                {
                    case "author":
                        author = parseStr;
                        break;
                    case "date":
                        date = parseStr;
                        break;
                    case "testDriver":
                        testDriver = parseStr;
                        break;
                    case "testDriverPro":
                        testDriverPro = parseStr;
                        break;
                    default:
                        break;
                }
                return parseStr;
            }
            return "";
        }

        //parse tested file 
        public List<string> parseList(string propertyName)
        {
            List<string> values = new List<string>();
            IEnumerable<XElement> parseElems = doc.Descendants(propertyName);
            if (parseElems.Count() > 0)
            {
                switch (propertyName)
                {
                    case "tested":
                        foreach (XElement elem in parseElems)
                        {
                            values.Add(elem.Value);
                        }
                        testedFiles = values;
                        break;
                    default:
                        break;
                }
            }
            return values;
        }
    }

#if (TEST_MYREQUEST)
    class Program
    {
       
        static void Main(string[] args)
        {
            Console.Write("\n  Testing TestRequest");
            Console.Write("\n =====================");

            string savePath = "../../test/";
            string fileName = "TestRequest1.xml";

            if (!System.IO.Directory.Exists(savePath))
                System.IO.Directory.CreateDirectory(savePath);
            string fileSpec = System.IO.Path.Combine(savePath, fileName);
            fileSpec = System.IO.Path.GetFullPath(fileSpec);

            Request tr = new Request();
            tr.author = "Jim Fawcett";
            tr.testDriver = "td1.cs";
            tr.testedFiles.Add("tf1.cs");
            tr.testedFiles.Add("tf2.cs");
            tr.testedFiles.Add("tf3.cs");
            tr.makeRequestXml();
            Console.Write("\n{0}", tr.doc.ToString());

            Console.Write("\n  saving to \"{0}\"", fileSpec);
            tr.saveXml(fileSpec);

            Console.Write("\n  reading from \"{0}\"", fileSpec);

            Request tr2 = new Request();
            tr2.loadXml(fileSpec);
            Console.Write("\n{0}", tr2.doc.ToString());
            Console.Write("\n");

            tr2.parse("author");
            Console.Write("\n  author is \"{0}\"", tr2.author);

            tr2.parse("testDriver");
            Console.Write("\n  testDriver is \"{0}\"", tr2.testDriver);

            tr2.parseList("tested");
            Console.Write("\n  testedFiles are:");
            foreach (string file in tr2.testedFiles)
            {
                Console.Write("\n    \"{0}\"", file);
            }
            Console.Write("\n\n");
        }

}
#endif
}