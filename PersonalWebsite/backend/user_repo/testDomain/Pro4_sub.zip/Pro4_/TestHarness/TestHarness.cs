﻿///////////////////////////////////////////////////////////////////////////
// TestHarness.cs - Receive request and test files                       //
//                                                                       //
// Biao A              ba1000@syr.edu                                    //    
// Application: CSE681 Project 4                                         //
// Environment: C# console                                               //
///////////////////////////////////////////////////////////////////////////
/* Ps: some codes come from 681 website
 * 
 * Package Operations:
 * -------------------
 * This package mainly includes the test function in this federation. It also contains functions like
 * creating an appdomain and cleaning temperary files which are helpful to do testing job.
 * 
 *  public interface: 
 *  TestHarness              - constructor: set path and clean files
 *  RcvThreadProc            - receive thread for TestHarness
 *  initializeDispatcher     - add Actions to dictionary(message dispatcher)
 *  
 *  other functions:
 *  Test                     - main process of test Harness
 *  RequestFile              - request child builder files based on the information from request
 *  ParseRequest             - parse the Test request from child builder
 *  Logger                   - create log for this test and send it to repo
 *  CreateAppDomain          - Create AppDomain in which to run tests
 *  LoadAndRun               - Load Loader and tests, run tests, unload AppDomain
 *  runTests                 - Run tests and return result
 *  UnloadTestDomain         - unload the app domain so that the files can be deleted
 *  cleaner                  - clean all the temp files
 * 
 *  Required Files:
 * ---------------
 *  CommServer.cs            - need Comm project to send and receive messages and files
 *  FileMgr.cs               - need some funcitons to deal with files
 *  Environment.cs           - get information like path, port...
 *  Loader.cs                - use loader to load a appdomain
 *  MyRequest.cs             - parse request to get information
 *  TestUtilities.cs            - need some functions in it
 *  
 *   Maintenance History:
 * --------------------
 * ver 1.0 : 06 Dec 2017
 * - first release
 */
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Remoting;
using System.Security.Policy;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Pro4
{
    class TestHarness
    {
        Dictionary<string, Action<CommMessage>> messageDispatcher = new Dictionary<string, Action<CommMessage>>();
        Comm comm { get; set; } = null;
        string path { get; set; } = "";
        Request request { get; set; } = new Request();
        string dllName { get; set; } = "";
        string xmlName { get; set; } = "";
        string logName { get; set; } = "";
        AppDomain ad { get; set; } = null;

        //constructor: set path and clean files
        public TestHarness()
        {
            try
            {
                FileMgr mgr = new FileMgr();
                mgr.Cleaner(TestHarnessEnvironment.root);
                path = Path.GetFullPath(TestHarnessEnvironment.root);
                comm = new Comm(TestHarnessEnvironment.address);

            }
            catch (Exception ex)
            {
                Console.WriteLine("\n  {0}", ex.Message);
            }
        }

        //receive thread for TestHarness
        public void RcvThreadProc()
        {
            Console.Write("\n  starting Test Harness process's receive thread");
            while (true)
            {
                CommMessage msg = comm.getMessage();
                Console.Write("\n  Get message from {0}!", msg.Source);
                messageDispatcher[msg.Command](msg);
            }
        }

        //initialize messageDispatcher - add Actions to dictionary(message dispatcher)
        public void initializeDispatcher()
        {
            Action<CommMessage> test = new Action<CommMessage>(Test);
            messageDispatcher["TestRequest"] = test;
        }

        /*main process of test Harness
         * including
         RequestFile - request child builder files based on the information from request
         runTests - run tests and return result 
         Logger - create log for this test can send it to repo
             */
        private void Test(CommMessage msg)
        {
            try
            {
                string xmlPath = Path.Combine(path, msg.Body);
                TestUtilities.waitForCompletion(xmlPath);
                RequestFile(msg);
                string result = runTests();
                Logger(msg, result);
                cleaner();
            }
            catch (Exception ex)
            {
                Console.Write("\n  {0}", ex.Message);
            }
        }

        //request child builder files based on the information from request
        private void RequestFile(CommMessage msg)
        {
            xmlName = msg.Body;
            ParseRequest(xmlName);
            CommMessage fileRequest = new CommMessage();
            string PreDllName = Path.GetFileNameWithoutExtension(request.testDriver) + ".dll";
            fileRequest.Body = PreDllName;
            fileRequest.Destinaiton = "Child Builder";
            fileRequest.Source = "Test Harness";
            fileRequest.Command = "FileRequest";
            comm.postMessage(fileRequest, msg.Address);
            string dllpath = Path.Combine(path, PreDllName);  
            TestUtilities.waitForCompletion(dllpath);
            dllName = "DllFor" + Path.GetFileNameWithoutExtension(msg.Body) + ".dll";
            Directory.Move(Path.Combine(path, PreDllName), Path.Combine(path, dllName));
            string notification = "Dll file is saved in " + Path.Combine(path, dllName);
            TestUtilities.notification(notification);
        }

        //parse the Test request from child builder
        private void ParseRequest(string xmlName)
        {
            try
            {
                string xmlFullName = Path.Combine(path, xmlName);
                request.loadXml(xmlFullName);
                request.parse("author");
                request.parse("date");
                request.parse("testDriver");
                request.parse("testDriverPro");
                request.parseList("tested");
            }
            catch (Exception ex)
            {
                Console.WriteLine("\n  {0}",ex.Message);
            }
        }

        //create log for this test and send it to repo
        private void Logger(CommMessage msg, string result)
        {
            string author = request.author;
            string name = Path.GetFileNameWithoutExtension(msg.Body);
            string time = DateTime.Now.ToString();
            string log = "\n  Name : " + name + "\n  Author : " + author
                + "\n  Time : " + time + "\n -------- " + result;
            string logPath = Path.Combine(path, "TestLogFor" + name + ".txt");
            FileStream fs = new FileStream(logPath, FileMode.Create);
            StreamWriter sw = new StreamWriter(fs);
            sw.Write(log);
            sw.Flush();
            sw.Close();
            fs.Close();
            string notification = "Sending log:" + "TestLogFor" + name + ".txt " + "to Repo!";
            TestUtilities.notification(notification);
            TestUtilities.requirment(9);
            logName = "TestLogFor" + name + ".txt";
            comm.postFile(logName, path, RepositoryEnvironment.root + "/log", RepositoryEnvironment.address);
        }

        //Create AppDomain in which to run tests
        private void CreateAppDomain()
        {
            AppDomainSetup domainInfo = new AppDomainSetup();
            domainInfo.ApplicationName = "TestDomain";
            Evidence evidence = AppDomain.CurrentDomain.Evidence;
            ad = AppDomain.CreateDomain("TestDomain", evidence, domainInfo);
        }

        //Load Loader and tests, run tests, unload AppDomain
        private string LoadAndRun()
        {
            Console.Write("\n\n  Loading and instantiating Loader in TestDomain");
            Console.Write("\n ------------------------------------------------");
            Thread.Sleep(1000);
            string dllPath = Path.Combine(path, dllName);
            ad.Load("Loader");
            ObjectHandle oh = ad.CreateInstance("loader", "Pro4.Loader");
            Loader ldr = oh.Unwrap() as Loader;
            ldr.SetPath(dllPath);
            string result = ldr.RunTests();
            TestUtilities.notification(result);
            return result;
        }

        // Run tests and return result
        private string runTests()
        {
            try
            {
                CreateAppDomain();
                string result = LoadAndRun();
                UnloadTestDomain();
                return result;
            }
            catch (Exception ex)
            {
                Console.Write("\n  {0}", ex.Message);
                return ex.Message;
            }
        }

        //unload the app domain so that the files can be deleted
        private void UnloadTestDomain()
        {
            AppDomain.Unload(ad);
            string notification = "unload appDomain!";
            TestUtilities.notification(notification);
        }

        //clean all the temp files
        private void cleaner()
        {
            FileMgr mgr = new FileMgr();
            string dllFile = Path.Combine(path, dllName);
            string xmlFile = Path.Combine(path, xmlName);
            string logFile = Path.Combine(path, logName);
            List<string> fileList = new List<string>();
            fileList.Add(dllFile);
            fileList.Add(xmlFile);
            fileList.Add(logFile);
            mgr.DeleteFileList(fileList);
        }
    }
    class test
    {
        static void Main(string[] args)
        {
            TestUtilities.title("This is TestHarness");
            TestHarness tH = new TestHarness();
            tH.initializeDispatcher();
            Thread t = new Thread(() => tH.RcvThreadProc());
            t.Start();
            t.Join();
            Console.ReadKey();
        }
    }
}
