﻿///////////////////////////////////////////////////////////////////////////////
// MainWindow.xaml.cs - GUI for demonstrating some functions of other part   //
//                                                                           //
// Biao A              ba1000@syr.edu                                        //    
// Application: CSE681 Project 4                                             //
// Environment: C# console                                                   //
///////////////////////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * -------------------
 * This package includes a GUI which client can browse files and send command.
 * 
 * functions:
 * MainWindow                     - constructor: initialize message dispatcher and open receive thread
 * Load                           - automatically run the whole process
 * InitializeMessageDispatcher    - initialize the message dispatcher
 *                                  repoFiles - receive the file list from repo and show it on the listbox
 *                                  repoRequest - receive the request list from repo and show it on the listbox
 * buildRequest_Click             - Button:create a build request                                
 * showFiles_Click                - Button:sends a message to repo to get file
 * sendRequest_Click              - Button:send request to repo
 * showContent_Click              - Button:show the request content 
 * build_Click                    - Button:let repo send request to builder and start process pool
 * refreshRequest_Click           - Button:send a msg to repo to refresh the request list
 * Stop_Clicks                    - Button:send a msg to build server to stop all its child processes
 * showDirs_Click                 - request repo send dir list
 * 
 * 
 * Required Files:
 * ---------------
 *  CommServer.cs     - need Comm project to send and receive messages and files
 *  MyRequest.cs      - builds request
 *  Environment.cs    - get information like path, port...
 *  TestUtilities     - need some functions in it
 *
 * Maintenance History:
 * --------------------
 * ver 1.0 : 06 Dec 2017
 * - first release
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Pro4;
using System.Threading;
using System.IO;

namespace GUI
{
    public partial class MainWindow : Window
    {
        Dictionary<string, Action<CommMessage>> messageDispatcher = new Dictionary<string, Action<CommMessage>>();
        Comm comm { get; set; } = null;
        Thread rcvThread = null;
        int ClickCount { get; set; } = 1;

        //constructor: initialize message dispatcher and open receive thread
        public MainWindow()
        {
            TestUtilities.title("This is Client.");
            TestUtilities.requirment(10);
            try
            {
                InitializeComponent();
                InitializeMessageDispatcher();
                comm = new Comm(ClientEnvironment.address);
                rcvThread = new Thread(rcvThreadProc);
                rcvThread.Start();
                stop.IsEnabled = false;
            }
            catch (Exception ex)
            {
                Console.WriteLine("\n  {0}",ex.Message);
            }
        }

        //automatically run the whole process
        public void Load(object sender, RoutedEventArgs e)
        {
            List<string> requestList = new List<string>();
            requestList.Add("request1.xml");
            requestList.Add("request2.xml");
            requestList.Add("request3.xml");
            requestList.Add("request4.xml");
            requestList.Add("request5.xml");
            requestList.Add("request6.xml");
            CommMessage msgToRepo = new CommMessage();
            foreach (var request in requestList)
            {
                msgToRepo.Body = request.ToString();
                msgToRepo.Source = "Client";
                msgToRepo.Destinaiton = "Repo";
                msgToRepo.Command = "SendRequest";
                comm.postMessage(msgToRepo, RepositoryEnvironment.address);
            }
            CommMessage msg = new CommMessage();
            int num = 3;
            msg.Body = num.ToString();
            msg.Source = "Client";
            msg.Destinaiton = "Build Server";
            msg.Command = "NumberOfChild";
            comm.postMessage(msg, BuildServerEnvironment.address);
            TestUtilities.requirment(5);
            stop.IsEnabled = true;
        }


        /*initialize the message dispatcher
         * repoFiles - receive the file list from repo and show it on the listbox
         * repoRequest - receive the request list from repo and show it on the listbox
         *  DirList     - receive the DirList from repo and show it on the listbox
        */
        void InitializeMessageDispatcher()
        {
            messageDispatcher["repoFiles"] = (CommMessage msg) =>
            {
                repoFiles.Items.Clear();
                Console.Write("\n  Receive file list from repo!");
                TestUtilities.requirment(11);
                foreach (var file in msg.MsgList)
                {
                    repoFiles.Items.Add(file);
                }
                
            };
            messageDispatcher["repoRequest"] = (CommMessage msg) =>
            {
                repoRequest.Items.Clear();
                Console.Write("\n  Receive request list from repo!");
                foreach (var file in msg.MsgList)
                {
                    repoRequest.Items.Add(file);
                }
            };
            messageDispatcher["DirList"] = (CommMessage msg) =>
            {
                repoDirs.Items.Clear();
                Console.Write("\n  Receive dir list from repo!");
                foreach (var dir in msg.MsgList)
                {
                    repoDirs.Items.Add(dir);
                }
            };
        }

        //define processing for GUI's receive thread
        void rcvThreadProc()
        {
            Console.Write("\n  starting client's receive thread");
            while (true)
            {
                CommMessage msg = comm.getMessage();
                Console.Write("\n  Get message from {0}!",msg.Source);
                Dispatcher.Invoke(messageDispatcher[msg.Command], new object[] { msg });
            }
        }

        //Button: create a build request
        private void buildRequest_Click(object sender, RoutedEventArgs e)
        {
            _buildRequest();
        }

        //create a build request
        private void _buildRequest()
        {
            TestUtilities.requirment(11);
            Request request = new Request();
            request.author = "Biao A";
            for (int i = 0; i < this.repoFiles.SelectedItems.Count; i++)
            {
                string fileName = repoFiles.SelectedItems[i].ToString();
                if (fileName.Contains("cs") && !fileName.Contains("csproj"))
                {
                    if (fileName.Contains("driver"))
                    {
                        request.testDriver = fileName;
                    }
                    else
                        request.testedFiles.Add(fileName.ToString());
                }
                if (fileName.Contains("csproj"))
                {
                    request.testDriverPro = fileName.ToString();
                }
            }

            string xmlName = "request" + ClickCount + ".xml";
            string fileSpec = System.IO.Path.Combine(ClientEnvironment.root, xmlName);
            fileSpec = System.IO.Path.GetFullPath(fileSpec);
            request.makeRequestXml();
            request.saveXml(fileSpec);
            Request.Items.Add(xmlName);
            ClickCount++;
            stop.IsEnabled = true;
        }

        //Button:sends a message to repo to get files
        private void showFiles_Click(object sender, RoutedEventArgs e)
        {
            _showFiles();
        }

        //sends a message to repo to get files
        private void _showFiles()
        {
            if (repoDirs.SelectedItem == null)
            {
                string warning = "Please at least select one dir!";
                MessageBox.Show(warning);
                return;
            }
            CommMessage msg = new CommMessage();
            msg.Source = "Client";
            msg.Destinaiton = "REPO";
            msg.Command = "FileListRequest";
            string dirName = repoDirs.SelectedItem.ToString();
            msg.Body = dirName;
            comm.postMessage(msg, RepositoryEnvironment.address);
        }

        //Button:send request to repo
        private void sendRequest_Click(object sender, RoutedEventArgs e)
        {
            _sendRequest();
        }

        //send request to repo
        private void _sendRequest() {
            if (Request.SelectedItem == null)
            {
                    string msg = "Please at least select one file!";
                    MessageBox.Show(msg);
                    return;
            }
            try
            {
                foreach (var request in Request.SelectedItems)
                {
                    string requestName = request.ToString();
                    string destination = System.IO.Path.GetFullPath(RepositoryEnvironment.root + "/request");
                    comm.postFile(requestName, ClientEnvironment.root, destination, RepositoryEnvironment.address);
                    //Thread.Sleep(1000);
                    CommMessage msgToRepo = new CommMessage();
                    msgToRepo.Body = request.ToString();
                    msgToRepo.Source = "Client";
                    msgToRepo.Destinaiton = "Repo";
                    msgToRepo.Command = "Request";
                    comm.postMessage(msgToRepo, RepositoryEnvironment.address);
                }
                string requestList = " ";
                foreach (var request in Request.SelectedItems)
                {
                    requestList = requestList + request.ToString() + ", ";
                }
                string msg = "Sent" + requestList + " successfully!";
                MessageBox.Show(msg);
            }
            catch (Exception ex)
            {
                Console.Write("\n  {0}", ex.Message);
            }
        }

        //Button:show the request content 
        private void showContent_Click(object sender, RoutedEventArgs e)
        {
            _showContent();
        }

        //show the request content 
        private void _showContent() {
            if (Request.SelectedItem == null)
            {
                string msg = "Please at least select one file!";
                MessageBox.Show(msg);
                return;
            }
            var fileNames = Request.SelectedItems;
            try
            {
                foreach (var file in fileNames)
                {
                    string fileName = file.ToString();
                    string path = System.IO.Path.Combine(ClientEnvironment.root, fileName);
                    string contents = File.ReadAllText(path);
                    PopUp popup = new PopUp();
                    popup.codeView.Text = contents;
                    popup.Show();
                    popup.Title = fileName;
                    //string ab = "ss";
                    //MessageBox.Show(ab);
                }
            }
            catch (Exception ex)
            {
                Console.Write("\n  {0}", ex.Message);
            }
        }

        //Button:let repo send request to builder and start process pool
        private void build_Click(object sender, RoutedEventArgs e)
        {
            _build();
        }

        //let repo send request to builder and start process pool
        private void _build() {
            try
            {
                TestUtilities.requirment(4);
                TestUtilities.requirment(5);
                int number = 0;
                if (number1.IsChecked == true) { number = 1; }
                if (number2.IsChecked == true) { number = 2; }
                if (number3.IsChecked == true) { number = 3; }
                if (number4.IsChecked == true) { number = 4; }
                if (number5.IsChecked == true) { number = 5; }
                if (number6.IsChecked == true) { number = 6; }
                if (number7.IsChecked == true) { number = 7; }
                if (number == 0)
                {
                    string warning = "Please at least select one number!";
                    MessageBox.Show(warning);
                    return;
                }
                CommMessage msgToRepo = new CommMessage();
                foreach (var request in repoRequest.SelectedItems)
                {
                    msgToRepo.Body = request.ToString();
                    msgToRepo.Source = "Client";
                    msgToRepo.Destinaiton = "Repo";
                    msgToRepo.Command = "SendRequest";
                    comm.postMessage(msgToRepo, RepositoryEnvironment.address);
                }
                CommMessage msg = new CommMessage();
                msg.Body = number.ToString();
                msg.Source = "Client";
                msg.Destinaiton = "Build Server";
                msg.Command = "NumberOfChild";
                comm.postMessage(msg, BuildServerEnvironment.address);
                stop.IsEnabled = true;
            }
            catch (Exception ex)
            {
                Console.Write("\n  {0}", ex.Message);
            }
        }

        //Button:send a msg to repo to refresh the request list
        private void refreshRequest_Click(object sender, RoutedEventArgs e)
        {
            _refreshRequest();
        }

        //send a msg to repo to refresh the request list
        private void _refreshRequest() {

            CommMessage msg = new CommMessage();
            msg.Command = "RequestList";
            msg.Body = "need request list to show";
            msg.Source = "Client";
            msg.Destinaiton = "Repo";
            comm.postMessage(msg, RepositoryEnvironment.address);
        }

        //Button:send a msg to build server to stop all its child processes
        private void Stop_Click(object sender, RoutedEventArgs e)
        {
            _Stop();
        }

        //send a msg to build server to stop all its child processes
        private void _Stop()
        {
            string notification = "Stop all child process";
            TestUtilities.notification(notification);
            CommMessage stopMsg = new CommMessage();
            stopMsg.Body = "stop";
            stopMsg.Source = "Client";
            stopMsg.Destinaiton = "Build Server";
            stopMsg.Command = "Stop";
            comm.postMessage(stopMsg, BuildServerEnvironment.address);
        }

        //request repo send dir list
        private void showDirs_Click(object sender, RoutedEventArgs e)
        {
            CommMessage dirRequest = new CommMessage();
            dirRequest.Body = "need dir list to show";
            dirRequest.Destinaiton = "Repo";
            dirRequest.Source = "Client";
            dirRequest.Command = "DirRequest";
            comm.postMessage(dirRequest,RepositoryEnvironment.address);
        }

    }
}
