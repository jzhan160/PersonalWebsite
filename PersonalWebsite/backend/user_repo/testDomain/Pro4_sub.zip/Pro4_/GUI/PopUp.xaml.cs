﻿///////////////////////////////////////////////////////////////////////////////
// PopUp.xaml.cs - show request content                                      //
//                                                                           //
// Biao A              ba1000@syr.edu                                        //    
// Application: CSE681 Project 4                                             //
// Environment: C# console                                                   //
///////////////////////////////////////////////////////////////////////////////
/*
 * package Operations:
 * This package is used to show request content 
 * 
 * public interface:
 * PopUp            - constructor
 * 
 * Maintenance History:
 * --------------------
 * ver 1.0 : 06 Dec 2017
 * - first release
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GUI
{
    public partial class PopUp : Window
    {
        //constructor
        public PopUp()
        {
            InitializeComponent();
        }
    }
}
